-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-05-2024 a las 04:35:51
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `innet`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pregunta`
--

CREATE TABLE `pregunta` (
  `id` int(11) NOT NULL,
  `pregunta` varchar(255) NOT NULL,
  `respuesta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pregunta`
--

INSERT INTO `pregunta` (`id`, `pregunta`, `respuesta`) VALUES
(1, 'Que es una variable?', 1),
(2, 'Que es una funcion?', 2),
(3, 'Que es la recursion?', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuesta`
--

CREATE TABLE `respuesta` (
  `id` int(11) NOT NULL,
  `pregunta_id` int(11) NOT NULL,
  `respuesta` varchar(255) NOT NULL,
  `correcta` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `respuesta`
--

INSERT INTO `respuesta` (`id`, `pregunta_id`, `respuesta`, `correcta`) VALUES
(1, 1, 'Es un espacio de almacenamiento que contiene un valor o un conjunto de valores.', 1),
(2, 2, 'Una función es un bloque de código reutilizable que realiza una tarea específica.', 1),
(3, 2, 'Es un una variable.', 0),
(4, 2, 'Es una pregunta', 0),
(5, 2, 'Ni idea.', 0),
(6, 1, 'Es algo que cambia.', 0),
(7, 3, 'Es donde una función se llama a sí misma en su definición.', 1),
(8, 3, 'Es donde una función llama a otra funcion', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `codigo_verificacion` varchar(32) NOT NULL,
  `verificado` tinyint(1) NOT NULL DEFAULT 0,
  `pass` varchar(50) NOT NULL,
  `nickname` varchar(30) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `fotografia` varchar(128) NOT NULL,
  `archivo_n` varchar(128) NOT NULL,
  `admin` int(2) NOT NULL DEFAULT 0,
  `status` varchar(20) NOT NULL,
  `unique_id` int(255) NOT NULL,
  `score` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `email`, `codigo_verificacion`, `verificado`, `pass`, `nickname`, `apellidos`, `fotografia`, `archivo_n`, `admin`, `status`, `unique_id`, `score`) VALUES
(51, 'Samantha', 'androlausam2@gmail.com', '9f77720ef7b5122aabf45b49dd1266c6', 1, '0cdfb256110772e88c21ddf94ee6f1ba', 'samnette', 'Telles', 'd06f547c157893df34569aa4ca374099.jpg', 'miyamurita.jpg', 1, 'Disponible', 987654321, 0),
(52, 'Alberto', 'dangatovolador@gmail.com', 'e51fadadb39f8d188f495ab3a663c924', 2, 'caf1a3dfb505ffed0d024130f58c5cfa', 'Juarez9516', 'Silva', '05abde1caafd58db602eada746fb7404.jpg', 'soyese.jpg', 0, 'Suspendido', 793683764, 0),
(53, 'Christian', 'cristiansillochavech@gmail.com', '97fda7f4e1bb04c48b022eb09f3d998b', 1, '827ccb0eea8a706c4c34a16891f84e7b', 'Cris Ruvalcaba', 'Ruvalcava', '47d9e075126125bd9f6b97850df044c6.jpg', 'crisfoto.jpg', 1, 'Offline', 549412433, 0),
(54, 'Trilce', 'trilceflores15@gmail.com', 'c466a0eae55f4e1042bab05e1d49e5d0', 1, '637460cd3f487aa97158cfcc01a2f6b4', 'trilce', 'Flores', '60a0d0ccbae677e42adc5592f771a1a2.jpg', 'trilcefoto.jpg', 1, 'Offline', 586934568, 0),
(55, 'Diego', 'diegoalejandrolopezcoronado@hotmail.com', '50e8d5e64f0c3f7c743e63489569c78e', 1, '49aadac47c39944fd6078ac36e7e53bc', 'diego', 'Lopez', 'e41253bb71e52c8f14a518a519c84ef3.jpeg', 'diegofoto.jpeg', 1, 'Offline', 785432076, 0),
(56, 'Logan', 'alphc056@gmail.com', 'a616abf9d883b7ec31b4a6f259685ed4', 1, '622be4f47f555a3f8fc87d1d7cf31430', 'alph56', 'Cuenca', 'ed7bbcb87ac9dbf04e3988a73bf81e17.png', 'Alphoto.png', 1, 'Offline', 639721044, 0),
(59, 'Andrea', 'androlausam@gmail.com', 'cbb9238c3e3cde53781704b323db15d0', 1, '827ccb0eea8a706c4c34a16891f84e7b', 'liz', 'Hernandez', 'ab1c3f06c23aca30625209cd0603b815.jpg', 'usuario.jpg', 0, 'Offline', 717902832, 0),
(60, 'Daniel Antonio', 'esequien333@gmail.com', '23f6fafc6cf29476853581452d988196', 1, '202cb962ac59075b964b07152d234b70', 'dancatfly', 'Juarez Silva', '14e89b59822683e66ad4af92ff6a70d8.png', 'grafo.png', 0, 'Disponible', 1411386702, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `respuesta`
--
ALTER TABLE `respuesta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pregunta_id` (`pregunta_id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pregunta`
--
ALTER TABLE `pregunta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `respuesta`
--
ALTER TABLE `respuesta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `respuesta`
--
ALTER TABLE `respuesta`
  ADD CONSTRAINT `respuesta_ibfk_1` FOREIGN KEY (`pregunta_id`) REFERENCES `pregunta` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
